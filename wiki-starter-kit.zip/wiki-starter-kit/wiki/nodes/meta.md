# Meta — What This Is

A personal knowledge graph. Markdown files connected by wikilinks, viewable in Obsidian as an interactive graph. Everything lives on your computer as local files — nothing is uploaded anywhere.

## How It Works

Talk to Claude. Claude writes it down. Pages get created, linked, and refined over time. The wiki is a persistent artifact — every conversation makes it richer. You can dump anything in: ideas, images, half-formed thoughts, family stories, work notes. Claude organizes it into the graph.

## Design Principles
- Stubs are fine — a placeholder beats a gap
- All data is valuable — don't decide what's important yet
- Wikilinks over prose repetition — facts live on their canonical page
- Capturing ideas is always the highest priority
- Log is diagnostic, not narrative
