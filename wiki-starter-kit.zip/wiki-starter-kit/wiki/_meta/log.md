# Log

Append-only diagnostic log. Format: `[date] ACTION PageName — note`
Actions: CREATED, UPDATED, RENAMED, DELETED, LINKED, CORRECTED, STUB
