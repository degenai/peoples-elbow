# Personal Wiki Starter Kit

A minimal setup for building a personal knowledge graph with Claude Code and Obsidian.

## What This Is

A folder of markdown files on your computer that Claude maintains for you. You talk, Claude writes it down as interconnected wiki pages. Over time it becomes a map of your life — people, places, projects, ideas — all linked together in a graph you can browse in Obsidian.

Everything is local. These are just text files on your hard drive. Nothing gets uploaded anywhere. You own the files.

You don't need to be a coder. You just need to talk.

This kit is bare bones on purpose. The structure, the procedures, the workflow — all of it is meant to grow around you. Your wiki won't look like anyone else's. That's the point.

## Setup

1. Install [Obsidian](https://obsidian.md/) (free)
2. Install Claude Code — web app (claude.ai/code) or desktop app both work
3. Open Claude Code and point it at this folder
4. Start talking

That's it. The `CLAUDE.md` file teaches Claude how to maintain the wiki. Claude reads it automatically.

### Where To Put It

You have two choices for where the wiki lives:

**Option A — Project folder.** Put this folder anywhere on your computer (Desktop, Documents, wherever). Open Claude Code pointed at it. Claude sees the CLAUDE.md and knows what to do. The wiki only loads when you're in that folder.

**Option B — Global Claude memory (what Alex does).** Same setup, you just tell Claude "put the wiki in your global config directory." Claude Code has a directory (`~/.claude/`) it reads in every session no matter what folder you're working in. So your wiki is always loaded — Claude always knows who your family is, what your projects are, what you talked about last time. You don't have to be "in the wiki folder" to add to it. You're just talking to Claude about anything and it has the full picture.

Not harder. Just a different answer to "where do you want the files?"

### Managing Your Usage (Pro Plan — $20/mo)

Claude Code shares your limit with regular Claude. If you also use Claude for work (writing, research, etc.), you need to budget.

- **Short sessions (under 30 min):** Use Opus. It's the strongest model — better at following complex wiki instructions, better at making connections. Worth the higher token cost for quick bursts.
- **Longer sessions (30+ min):** Switch to Sonnet. Still very capable, burns through your limit slower. Good for extended interview sessions or big lint passes.
- **Big asks, big questions:** Switch back to Opus for those. If you're asking Claude to restructure a whole section or reason about something complex, Opus is worth it.

You have several daily limits and a weekly limit. The goal is to use as much of your limit as possible — that's what you're paying for. But if you know you need Claude for other work that day, don't burn it all on the wiki. Sonnet gives you more runway.

You can check your remaining limit, but the method depends on whether you're using the web app, desktop app, or CLI — look for it in settings or ask Claude "how much usage do I have left."

**A note on CLI vs web/desktop:** CLI is just Claude Code running in the command prompt — a text-only terminal, no buttons, no sidebar. Same Claude, same capabilities. Alex prefers it because the stripped-down interface narrows focus and lets you watch exactly what Claude is doing step by step — every file read, every edit, every decision is visible. For wiki work, the web app or desktop app is perfectly fine and more approachable. The CLI is there if you ever want it.

## What You Can Do

- **"Interview me."** Claude switches into extraction mode and asks you questions. Every answer becomes wiki pages — people get their own page, places get their own page, connections get wikilinked. This is the fastest way to build out the graph.
- **"Add [anything]."** Dump any idea, image, memory, or note. Claude finds the right page for it or creates a new one.
- **"Lint the wiki."** Claude checks for broken links, orphan pages, missing connections, and fixes them.
- **"Show me what we have."** Claude can summarize the graph, find gaps, suggest what to explore next.

## Viewing in Obsidian

Open the `wiki/` folder as an Obsidian vault. You get:
- A graph view showing all your pages and how they connect
- Click any node to read the page
- Wikilinks are clickable navigation
- The graph grows as you add more

---

## How Alex Uses This (Usage Patterns)

This kit comes from Alex Adamczyk, who has been building a personal knowledge graph called Alexpedia since spring 2026. Here's how the workflow actually works in practice.

### The Core Loop

1. **Talk.** Just talk to Claude. About your day, your family, a project, an idea, a memory. Claude captures what surfaces — new people, new connections, corrections to old info.
2. **Capture.** Pages get created or updated in real time. Stubs are fine. A page with one sentence is better than no page.
3. **Lint.** Periodically ask Claude to check the graph for broken links, bare mentions, orphans. This is housekeeping — it keeps the connections tight.
4. **Log.** Every edit gets logged. Not for journaling — so the next session can see what happened and pick up where you left off.

### Curious Betsy — The Interview Protocol

The fastest way to flesh out a wiki is to have Claude interview you. Alex uses a persona called "Curious Betsy" — a warm, invasive, chain-smoking Southern woman who asks questions you wouldn't think to answer. The persona disarms you into giving real details.

You don't need Betsy specifically. The pattern is:
- Tell Claude to ask you questions about a topic (your family, your job, a project)
- Claude asks specific, branching questions — not "tell me about your mom" but "what did your mom do for work, and did she like it?"
- Every answer gets captured into the graph immediately
- Claude follows threads — if you mention a person, Claude asks about that person. If you mention a place, that place gets a page.

One 30-minute interview session can produce 10-20 wiki pages. The graph builds fast when someone is pulling answers out of you.

### Subagents — Telling Claude What to Do

Alex uses "subagents" — these are just written instructions (markdown files) that tell Claude to do a specific task. They're not automation. You decide when to run them. Examples:

- **Interviewer** — "Ask me questions and capture the answers into the wiki"
- **Linter** — "Check the wiki for broken links and fix them"
- **Scout** — "Look at how other people structure their knowledge graphs and suggest one improvement"

You can make your own. Write a markdown file that says what the agent should do, what it should avoid, and what the output looks like. Then tell Claude "run [agent name]" when you want it.

### Dump Anything In

The beauty of the wiki is you can throw ANYTHING at it:
- A half-formed idea at 2am
- A photo of a receipt
- A voice-to-text ramble about your grandmother
- A screenshot of something interesting
- A link you want to remember
- A correction to something you said last week

Claude files it into the graph. Creates a page if needed, updates an existing one if it fits, adds wikilinks to connect it. The wiki is a persistent artifact — it doesn't forget, it doesn't lose context between sessions, and it only gets richer over time.

The key insight: **don't curate at capture time.** Put everything in. The graph holds it all. You decide what matters later — the capture should be indiscriminate.

### Obsidian as the Viewer

The markdown files are the source of truth. Obsidian is just the viewer — but it's a good one. The graph view shows you the shape of your knowledge: clusters of densely connected pages, orphans floating alone, bridges between topics. It makes the invisible structure visible.

Alex's graph has ~70 nodes after about 10 days of building. Yours will look different — the structure reflects your life, not a template.

### What Makes This Work

- **Claude remembers across the session.** The CLAUDE.md file gives it the rules. The log gives it the history. The wiki gives it the context.
- **You don't write markdown.** You talk. Claude writes. You review in Obsidian.
- **Stubs compound.** A page with one sentence today becomes a full page next week when the topic comes up again. Nothing is wasted.
- **The graph teaches you what you know.** Looking at the Obsidian graph reveals connections you didn't realize were there. It's a mirror, not just a notebook.
